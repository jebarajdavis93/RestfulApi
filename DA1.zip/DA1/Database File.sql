CREATE DATABASE my_bank;
 
USE my_bank;
 
--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `number` int(11) NOT NULL PRIMARY KEY,
  `name` varchar(250) DEFAULT NULL,
  `pin_hash` varchar(250) NOT NULL,
  `balance` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `number` int(11) NOT NULL,
  `type` varchar(250) NOT NULL,
  `amount` int(11) NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

 
ALTER TABLE  `transaction` ADD FOREIGN KEY (  `number` ) REFERENCES  `card`.`number` (
`number`
) ON DELETE CASCADE ON UPDATE CASCADE ;
